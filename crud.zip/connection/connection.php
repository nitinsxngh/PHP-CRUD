<?php
// Database Connection
$dbhost = "localhost";
$username = "root";
$password = "";
$dbname = "crud";

$conn = mysqli_connect($dbhost,$username,$password,$dbname);

?>